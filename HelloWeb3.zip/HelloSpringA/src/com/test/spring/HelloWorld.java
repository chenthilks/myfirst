package com.test.spring;
public class HelloWorld 
{
  private String message;
	/**
	 * @param args
	 */
 public void getMessage()
 { 
	System.out.println("The Message..."+message);
 }
 public void setMessage(String message)
 {
	this.message = message;
 }
}