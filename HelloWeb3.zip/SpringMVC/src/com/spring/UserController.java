package com.spring;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class UserController extends MultiActionController{
	   
   public ModelAndView home(HttpServletRequest request,
		      HttpServletResponse response) throws Exception {
		      ModelAndView model = new ModelAndView("select");
		      model.addObject("message", "select");
		      return model;
		   }

   public ModelAndView create(HttpServletRequest request,
      HttpServletResponse response) throws Exception 
      {
      ModelAndView model = new ModelAndView("create");
      model.addObject("message", "create");
      return model;
   }

      
   public ModelAndView read(HttpServletRequest request,
		   HttpServletResponse response) throws Exception
		   {
		      ModelAndView model = new ModelAndView("read");
		      model.addObject("message", "read");
		      return model;
		   }
   public ModelAndView update(HttpServletRequest request,
		   HttpServletResponse response) throws Exception
		   {
		      ModelAndView model = new ModelAndView("update");
		      model.addObject("message", "update");
		      return model;
		   }
   public ModelAndView delete(HttpServletRequest request,
		  HttpServletResponse response) throws Exception 
		  {
		      ModelAndView model = new ModelAndView("delete");
		      model.addObject("message", "delete");
		      return model;
		  }
}

