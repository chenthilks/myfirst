package pubhub.dao;

import java.util.List;

import pubhub.model.Book;

public interface BookInterface {
	public void AddBook(Book book)throws Exception;
	public void RemoveBook(Book book) throws Exception;
	public List<Book> listBooks(Book book)throws Exception;

}
