package pubhub.dao;

import java.util.List;

import pubhub.model.BookTag;

public interface BookTagDAO 
{
	public boolean addTag(BookTag bookTag);
	public boolean removeTag(BookTag bookTag);
	public boolean updateTag(BookTag bookTag);
	
	public List<BookTag> retrieveAllBookDetails();
}
