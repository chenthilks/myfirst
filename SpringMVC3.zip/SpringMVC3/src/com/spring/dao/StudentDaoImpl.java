package com.spring.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spring.model.StudentModel;

@Repository("studentDao")
public class StudentDaoImpl implements StudentDao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public void addStudent(StudentModel student) 
	{
		sessionFactory.getCurrentSession().saveOrUpdate(student);
	}
	@SuppressWarnings("unchecked")
	public List<StudentModel> listStudents() {
		return (List<StudentModel>) sessionFactory.getCurrentSession().createCriteria(StudentModel.class).list();
	}
	public StudentModel getStudent(int studid) {
		StudentModel sm=null;
		try{
		sm=(StudentModel)sessionFactory.getCurrentSession().get(StudentModel.class, studid);
		}
		catch(Exception e)
		{System.out.println(e);}
	     return sm;	
	}
	public boolean deleteStudent(StudentModel student) 
	{
		    Session session=sessionFactory.openSession();
		    Query qry=session.createQuery("Select count(id) from student_info2");
		    Iterator count = qry.iterate();
		    Long val1=(Long)count.next();
		    System.out.println(val1);
			sessionFactory.getCurrentSession().createQuery("DELETE FROM student_info2 WHERE id = "+student.getId()).executeUpdate();
			Query qry2=session.createQuery("Select count(distinct si.id) from student_info2 si");
		    Iterator count2 = qry.iterate();
		    Long val2=(Long)count2.next();	 
		    System.out.println(val2);
		    if(val2<val1)
		    {
		    	return true;
		    }
		    else
		    {return false;}
		    
		    
	}
}
