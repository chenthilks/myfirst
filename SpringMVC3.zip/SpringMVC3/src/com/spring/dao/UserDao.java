package com.spring.dao;

import com.spring.model.UserModel;

public interface UserDao
{
	public UserModel getUser(int uid);
}
