package com.spring.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spring.model.UserModel;

@Repository("userDao")
public class UserDaoImpl implements UserDao
{
	@Autowired
	private SessionFactory sessionFactory;

	public UserModel getUser(int uid) {
		return (UserModel)sessionFactory.getCurrentSession().get(UserModel.class, uid);
	}

	
}
