package com.spring.dao;

import java.util.List;


import com.spring.model.StudentModel;

public interface StudentDao
{
	public void addStudent(StudentModel student);

	public List<StudentModel> listStudents();
	
	public StudentModel getStudent(int studid);
	
	public boolean deleteStudent(StudentModel student);

	
}
