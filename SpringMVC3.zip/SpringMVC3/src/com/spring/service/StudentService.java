package com.spring.service;
import java.util.List;

import com.spring.model.StudentModel;

public interface StudentService
{
	public void addStudent(StudentModel student);

	public List<StudentModel> listStudents();
	
	public StudentModel getStudent(int id);
	
	public boolean deleteStudent(StudentModel student);

}
