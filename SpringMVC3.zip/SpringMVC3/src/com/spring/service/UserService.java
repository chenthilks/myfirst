package com.spring.service;

import com.spring.model.UserModel;



public interface UserService
{
	public UserModel getUser(int uid);
	
}
