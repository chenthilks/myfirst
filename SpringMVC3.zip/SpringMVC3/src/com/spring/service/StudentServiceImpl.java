package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.StudentDao;
import com.spring.model.StudentModel;

/**
 * @author Dinesh Rajput
 *
 */
@Service("studentService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao studentDao;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addStudent(StudentModel student) 
	{
		studentDao.addStudent(student);
	}
	
	public List<StudentModel> listStudents() 
	{
		return studentDao.listStudents();
	}

	public StudentModel getStudent(int studid) 
	{
		return studentDao.getStudent(studid);
	}

	public boolean deleteStudent(StudentModel student)
	{
		return studentDao.deleteStudent(student);
		
	}
}
