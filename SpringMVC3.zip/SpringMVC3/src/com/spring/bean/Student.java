package com.spring.bean;

//import org.hibernate.validator.constraints.NotEmpty;
//import org.hibernate.validator.constraints.Range;

public class Student
{          //@NotEmpty(message="ID cannot be empty")
	       private Integer id;
		   private String fname;
		   private String lname;
		   private String etype;
		   private String phoneno;
		   private String mailid;
		   private String empdoj;
		   private String empdesig;
		   private String dob;
		   private String mailid2;
		   private String mobileno;
		   private String phoneno2;
		   private String fathername;
		   private String eaddress1;
		   private String eaddress2;
		   private String eaddress3;
		   private String previousem;
		   private String finyear;
		   private String sdate;
		   private String edate;
		   private String esalary;
		   private String taxpaid;
		   private String value;
		   public void setId(Integer id) {
		      this.id = id;
		   }
		   public Integer getId() {
		      return id;
		   }

		   public void setFname(String fname) {
		      this.fname = fname;
		   }
		   public String getFname() {
		      return fname;
		   }

		   public void setLname(String lname) {
			      this.lname = lname;
			   }
			   public String getLname() {
			      return lname;
			   }
			   public void setEtype(String etype) {
				      this.etype = etype;
				   }
				   public String getEtype() {
				      return etype;
				   }
				   public void setPhoneno(String phoneno) {
					      this.phoneno = phoneno;
					   }
					   public String getPhoneno() {
					      return phoneno;
					   }
					   public void setMailid(String mailid) {
						      this.mailid = mailid;
						   }
						   public String getMailid() {
						      return mailid;
						   }
						   public void setEmpdoj(String empdoj) {
							      this.empdoj = empdoj;
						   }
						  public String getEmpdoj() {
							      return empdoj;
						   }
						   public void setEmpdesig(String empdesig) {
							      this.empdesig = empdesig;
						   }
						  public String getEmpdesig() {
							      return empdesig;
						   }
						   public void setDob(String dob) {
							      this.dob = dob;
						   }
						  public String getDob() {
							      return dob;
						   }
						  public void setMailid2(String mailid2) {
						      this.mailid2 = mailid2;
					   }
					  public String getMailid2() {
						      return mailid2;
					   }
					  public void setMobileno(String mobileno) {
					      this.mobileno = mobileno;
				   }
				  public String getMobileno() {
					      return mobileno;
				   }
				  public void setPhoneno2(String phoneno2) {
				      this.phoneno2 = phoneno2;
			   }
			  public String getPhoneno2() {
				      return phoneno2;
			   }
			  
						  
						   public void setFathername(String fathername) {
							      this.fathername = fathername;
						   }
						  public String getFathername() {
							      return fathername;
						   }
						   public void setEaddress1(String eaddress1) {
							      this.eaddress1 = eaddress1;
						   }
						  public String getEaddress1() {
							      return eaddress1;
						   }
						  public void setEaddress2(String eaddress2) {
						      this.eaddress2 = eaddress2;
					   }
					   public String getEaddress2() 
					   {
						      return eaddress2;
					   }
					  public void setEaddress3(String eaddress3) 
					   {
						      this.eaddress3 = eaddress3;
					   }
					  public String getEaddress3() {
						      return eaddress3;
					   }
						   public void setPreviousem(String previousem) {
							      this.previousem =previousem;
						   }
						  public String getPreviousem() {
							      return previousem;
						   }
						public void setFinyear(String finyear) {
							      this.finyear = finyear;
						   }
						  public String getFinyear() {
							      return finyear ;
						   }
						   public void setSdate(String sdate) {
							      this.sdate = sdate;
						   }
						  public String getSdate() {
							      return sdate;
						   }
						   public void setEdate(String edate) {
							      this.edate = edate;
						   }
						  public String getEdate() {
							      return edate;
						   }
						   public void setEsalary(String esalary) {
							      this.esalary = esalary;
						   }
						  public String getEsalary() {
							      return esalary;
						   }
						   public void setTaxpaid(String taxpaid) {
							      this.taxpaid = taxpaid;
						   }
						  public String getTaxpaid() {
							      return taxpaid;
						   }
						public String getValue() {
							return value;
						}
						public void setValue(String value) {
							this.value = value;
						}		  
}
