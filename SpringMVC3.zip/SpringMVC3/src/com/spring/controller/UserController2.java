package com.spring.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.SimpleFormController;
import org.springframework.ui.ModelMap;



import com.service.DBOperation1;
import com.service.DBOperation2;
import com.service.DBOperation3;
import com.service.DBOperation4;
import com.service.DBOperation5;


import com.spring.bean.Student;
import com.spring.bean.User;
import com.spring.model.StudentModel;
import com.spring.model.UserModel;
import com.spring.service.StudentService;
import com.spring.service.UserService;

@Controller
public class UserController2// extends SimpleFormController
{
	
	private StudentValidator validator;

	@Autowired
	private UserService userService;
	@Autowired
	private StudentService studentService;
	
	@Autowired
	public UserController2(StudentValidator validator)
	{
		this.validator = validator;
	}
	
	/*
	public UserController2()
	                 {
		 		         setCommandClass(Student.class);
		 		         setCommandName("Student");
		 		     }

	    @Override
	    protected ModelAndView onSubmit(Object command, BindException errors) throws Exception 
	    {
	   
	    	   ModelAndView mv = new ModelAndView();
	           if(errors.hasErrors())
	           {
	                 mv.setViewName(getFormView());
	    
	           }
	      else{
	    
	                mv.addObject("Student", command);
	    
	                mv.setViewName(getSuccessView());
	    
	           }	    
	            return mv;	    
	   }

	   @Autowired
	   @Qualifier("studentValidator")
	   private Validator validator;

	   @InitBinder
	   private void initBinder(WebDataBinder binder)
	   {
	      binder.setValidator(validator);
	   }	   
*/	
		 @RequestMapping(value="/login", method=RequestMethod.GET)
		 public ModelAndView login() {
			   //return new ModelAndView("index","command",new User());
			   ModelAndView model = new ModelAndView("index","command",new User());
			   model.addObject("message", "This is the Login Page");
			   return model;
		  }
		 @RequestMapping(value="/login2", method = RequestMethod.POST)
		 public String login(@ModelAttribute("SpringWeb")User user,BindingResult result, ModelMap model) 
		 {
		     int uid=0;
		     boolean status=false;
		     boolean flag = false;
			 if(user.getUserName().equals("admin") && user.getPassword().equals("admin"))
			 {
				 uid=1;
			 }
			 
			 UserModel um= (UserModel)userService.getUser(uid);
		     if(um != null)
		     {	 
			 if(um.getUserId()==1)
			 {
				 status=true;
				 flag=true;
			 }
		     }
			 
	     /*
		 DBOperation1 ref=new DBOperation1(); 
		 boolean status=false;
		 boolean flag;
		 status=ref.DBOP1(user.getUserName(),user.getPassword());
		 flag=ref.getFlag();
		 */
		 System.out.println("U.FLAG:"+flag);
		 System.out.println("U.STATUS:"+status);					      
		 if((status==true) && (flag == true))
		 {
			 return "buttons";
		 }	
		 else if(flag==false)
		 {
				  result.addError(new FieldError("SpringWeb","value","The user name and or password is wrong"));
				  return "error";
		 }			  	 
	        return "";
		 }	 		    
		 
	 @RequestMapping(value="/buttons", method = RequestMethod.POST)
	  public ModelAndView home(HttpServletRequest request,
	  HttpServletResponse response) throws Exception {
	  ModelAndView model = new ModelAndView("buttons");
	  model.addObject("message", "buttons");
	  return model;
	  }
	
	 @RequestMapping("/select")
	  public ModelAndView select(HttpServletRequest request,
	  HttpServletResponse response) throws Exception {
	  ModelAndView model = new ModelAndView("select");
	  model.addObject("message", "SPRING CRUD");
	  return model;
	  }

	  
	  @RequestMapping("/blank")
	  public ModelAndView blank(HttpServletRequest request,
	  HttpServletResponse response) throws Exception {
	  ModelAndView model = new ModelAndView("blank");
	  model.addObject("message", "blank");
	  return model;
	  }
	  
	  @RequestMapping("/exit")
	  public ModelAndView exit(HttpServletRequest request,
	  HttpServletResponse response) throws Exception
	  {
	     ModelAndView model = new ModelAndView("exit");
	     model.addObject("message", "exit");
	     return model;
	  }	  

	 @RequestMapping(value = "/create", method = RequestMethod.GET)
	 public String index(Map<String, Object> model) {
	 StudentModel student = new StudentModel();
	 model.put("student", student);
	 return "create";
	  }
	
	 /* 	  
	  @RequestMapping(value = "/create", method = RequestMethod.GET)
	  public ModelAndView student() {
	  return new ModelAndView("create", "command", new Student());
	  }
	  */
	 @RequestMapping(value = "/addStudent", method = RequestMethod.POST)
	  public String addStudent(@ModelAttribute("student")StudentModel student,BindingResult result, 
	  ModelMap model) {
	  	  	  
		 
	  validator.validate(student, result);
	  if (result.hasErrors()) {
			return "create";
		}
	  
	 
	  //boolean status=false;
	 // status=new DBOperation2().DBOP2(student); 
	 // studentService.addStudent(student);
	  
	  //if (status==true){
	 
	  
	  studentService.addStudent(student);
	
	  if(student.getFname()!=null)
	  {
	  model.addAttribute("id", student.getId());
	  model.addAttribute("fname", student.getFname());
	  model.addAttribute("lname", student.getLname());
	  model.addAttribute("etype", student.getEtype());
	  model.addAttribute("phoneno", student.getPhoneno());
	  model.addAttribute("mailid", student.getMailid());
	  model.addAttribute("empdoj", student.getEmpdoj());
	  model.addAttribute("empdesig", student.getEmpdesig());
	  model.addAttribute("dob", student.getDob());
	  model.addAttribute("mailid2", student.getMailid2());
	  model.addAttribute("mobileno", student.getMobileno());
	  model.addAttribute("phoneno2", student.getPhoneno2());
	  model.addAttribute("fathername", student.getFathername());
	  model.addAttribute("eaddress1", student.getEaddress1());
	  model.addAttribute("eaddress2", student.getEaddress2());
	  model.addAttribute("eaddress3", student.getEaddress3());
	  model.addAttribute("employername", student.getPreviousem());
	  model.addAttribute("finyear", student.getFinyear());
	  model.addAttribute("sdate", student.getSdate());
	  model.addAttribute("edate", student.getEdate());
	  model.addAttribute("esalary", student.getEsalary());
	  model.addAttribute("taxpaid", student.getTaxpaid());
	     }
	    else{}
			
	  return "result";
	    }
	      
	
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	 public ModelAndView student2() {
	  return new ModelAndView("read", "command", new Student());
	  }
		   
	 @RequestMapping(value = "/readStudent", method = RequestMethod.POST)
	 public String readStudent(@ModelAttribute("SpringWeb")Student student2, 
	 BindingResult result2, ModelMap model)
	 {
	 //DBOperation3 ref=new DBOperation3(); 
	      //boolean status=false;
		  //List newList=null;
		
		 int passVal=student2.getId();
		 StudentModel sm=(StudentModel)studentService.getStudent(passVal);
		 
		  /*
	      status=ref.DBOP3(student2); 
			  List listVal;
			  List listVal2;
			  List listVal3;
			  boolean flag;			  
			  flag=ref.getFlag();
			  System.out.println("R.FLAG:"+flag);
			  System.out.println("R.STATUS:"+status);
			  
			   if((status==true) && (flag == true))
			   {	            
				listVal  = ref.getListValue();
	    		System.out.println("////"+listVal);
	    		listVal2 = ref.getListValue2();
	            listVal3 = ref.getListValue3();	     
	      */
	      
	      
	      
		  /*
		  student2.setFname((String)listVal.get(0));
	            student2.setLname((String)listVal.get(1));
	            student2.setEtype((String)listVal.get(2));
	            student2.setPhoneno((String)listVal.get(3));
	            student2.setMailid((String)listVal.get(4));
	            student2.setEmpdoj((String)listVal.get(5));
	            student2.setEmpdesig((String)listVal.get(6));
	            student2.setDob((String)listVal2.get(0));
	            student2.setMailid2((String)listVal2.get(1));
	            student2.setMobileno((String)listVal2.get(2));
	            student2.setPhoneno2((String)listVal2.get(3));
	            student2.setFathername((String)listVal2.get(4));
	            student2.setEaddress1((String)listVal2.get(5));
	            student2.setEaddress2((String)listVal2.get(6));
	            student2.setEaddress3((String)listVal2.get(7));
	            student2.setPreviousem((String)listVal3.get(0));
	            student2.setFinyear((String)listVal3.get(1));
	            student2.setSdate((String)listVal3.get(2));
	            student2.setEdate((String)listVal3.get(3));
	            student2.setEsalary((String)listVal3.get(4));
	            student2.setTaxpaid((String)listVal3.get(5));
	        */
		 if(sm!=null)
		 {
		 if(sm.getId()!=null)
		 {		 
		  student2.setId(sm.getId());
		  student2.setFname(sm.getFname());
          student2.setLname(sm.getLname());
          student2.setEtype(sm.getEdate());
          student2.setPhoneno(sm.getPhoneno());
          student2.setMailid(sm.getMailid());
          student2.setEmpdoj(sm.getEmpdoj());
          student2.setEmpdesig(sm.getEmpdesig());
          student2.setDob(sm.getDob());
          student2.setMailid2(sm.getMailid());
          student2.setMobileno(sm.getMobileno());
          student2.setPhoneno2(sm.getPhoneno2());
          student2.setFathername(sm.getFathername());
          student2.setEaddress1(sm.getEaddress1());
          student2.setEaddress2(sm.getEaddress2());
          student2.setEaddress3(sm.getEaddress3());
          student2.setPreviousem(sm.getPreviousem());
          student2.setFinyear(sm.getFinyear());
          student2.setSdate(sm.getSdate());
          student2.setEdate(sm.getEdate());
          student2.setEsalary(sm.getEsalary());
          student2.setTaxpaid(sm.getTaxpaid());
        
		  
		          model.addAttribute("id", student2.getId());
			      model.addAttribute("fname", student2.getFname());
			      model.addAttribute("lname", student2.getLname());
			      model.addAttribute("etype", student2.getEtype());
			      model.addAttribute("phoneno", student2.getPhoneno());
			      model.addAttribute("mailid", student2.getMailid());
			      model.addAttribute("empdoj", student2.getEmpdoj());
			      model.addAttribute("empdesig", student2.getEmpdesig());
			      model.addAttribute("dob", student2.getDob());
			      model.addAttribute("mailid2", student2.getMailid2());
			      model.addAttribute("mobileno", student2.getMobileno());
			      model.addAttribute("phoneno2", student2.getPhoneno2());
			      model.addAttribute("fathername", student2.getFathername());
			      model.addAttribute("eaddress1", student2.getEaddress1());
			      model.addAttribute("eaddress2", student2.getEaddress2());
			      model.addAttribute("eaddress3", student2.getEaddress3());
			      model.addAttribute("employername", student2.getPreviousem());
			      model.addAttribute("finyear", student2.getFinyear());
			      model.addAttribute("sdate", student2.getSdate());
			      model.addAttribute("edate", student2.getEdate());
			      model.addAttribute("esalary", student2.getEsalary());
			      model.addAttribute("taxpaid", student2.getTaxpaid());
			      return "result2";
		 }
		 }	
		  else if(sm==null) 
		  {
			  result2.addError(new FieldError("SpringWeb","value1","The requested id is not available"));
			  return "error";
		  }
		return "";
		 
			
		/*	  else if(flag==false)
			  {
				  result2.addError(new FieldError("SpringWeb","value1","The requested id is not available"));
				  return "error";
			  }
			*/  			   
		  }   
		       
	 
	       @RequestMapping(value = "/update.html", method = RequestMethod.GET)
		   public ModelAndView student3() 
	       {
		      return new ModelAndView("update", "command", new StudentModel());
		   }
		   
		   @RequestMapping(value = "/updateStudent", method = RequestMethod.POST)
		   public String updateStudent(@ModelAttribute("SpringWeb")StudentModel student3, 
		   BindingResult result3,ModelMap model,Map<String, Object> model2) 
		   {
		       
			   /*
			      DBOperation3 ref=new DBOperation3(); 
			 	  boolean status=ref.DBOP3(student3); 
				  List listVal;
				  List listVal2;
				  List listVal3;
				  boolean flag;
				  flag=ref.getFlag();
				  System.out.println("U.FLAG:"+flag);
				  System.out.println("U.STATUS:"+status);
				
				  //boolean error=false;
				  if((status==true) && (flag == true))
				  {
		         
					listVal  = ref.getListValue();
		    		System.out.println("////"+listVal);
		    		listVal2 = ref.getListValue2();
		            listVal3 = ref.getListValue3();	     
		         */
			   
		
     		   int passVal=student3.getId();
	        	 StudentModel sm=(StudentModel)studentService.getStudent(passVal);
		 		 
	        	 if(sm!=null)
	        	 {
		          if(sm.getId()!= null)
		          {
		        	  student3.setId(sm.getId());
		    		  student3.setFname(sm.getFname());
		              student3.setLname(sm.getLname());
		              student3.setEtype(sm.getEdate());
		              student3.setPhoneno(sm.getPhoneno());
		              student3.setMailid(sm.getMailid());
		              student3.setEmpdoj(sm.getEmpdoj());
		              student3.setEmpdesig(sm.getEmpdesig());
		              student3.setDob(sm.getDob());
		              student3.setMailid2(sm.getMailid());
		              student3.setMobileno(sm.getMobileno());
		              student3.setPhoneno2(sm.getPhoneno2());
		              student3.setFathername(sm.getFathername());
		              student3.setEaddress1(sm.getEaddress1());
		              student3.setEaddress2(sm.getEaddress2());
		              student3.setEaddress3(sm.getEaddress3());
		              student3.setPreviousem(sm.getPreviousem());
		              student3.setFinyear(sm.getFinyear());
		              student3.setSdate(sm.getSdate());
		              student3.setEdate(sm.getEdate());
		              student3.setEsalary(sm.getEsalary());
		              student3.setTaxpaid(sm.getTaxpaid());
		            
		    		  
		    		          model.addAttribute("id", student3.getId());
		    			      model.addAttribute("fname", student3.getFname());
		    			      model.addAttribute("lname", student3.getLname());
		    			      model.addAttribute("etype", student3.getEtype());
		    			      model.addAttribute("phoneno", student3.getPhoneno());
		    			      model.addAttribute("mailid", student3.getMailid());
		    			      model.addAttribute("empdoj", student3.getEmpdoj());
		    			      model.addAttribute("empdesig", student3.getEmpdesig());
		    			      model.addAttribute("dob", student3.getDob());
		    			      model.addAttribute("mailid2", student3.getMailid2());
		    			      model.addAttribute("mobileno", student3.getMobileno());
		    			      model.addAttribute("phoneno2", student3.getPhoneno2());
		    			      model.addAttribute("fathername", student3.getFathername());
		    			      model.addAttribute("eaddress1", student3.getEaddress1());
		    			      model.addAttribute("eaddress2", student3.getEaddress2());
		    			      model.addAttribute("eaddress3", student3.getEaddress3());
		    			      model.addAttribute("employername", student3.getPreviousem());
		    			      model.addAttribute("finyear", student3.getFinyear());
		    			      model.addAttribute("sdate", student3.getSdate());
		    			      model.addAttribute("edate", student3.getEdate());
		    			      model.addAttribute("esalary", student3.getEsalary());
		    			      model.addAttribute("taxpaid", student3.getTaxpaid());
		    			      model2.put("student3", student3);
		    			      return "update2";	      
		    		//}
		          
	        	    }	
		         }
				  else if(sm==null) 
				  {
					  result3.addError(new FieldError("SpringWeb","value1","The requested id is not available"));
					  return "error";
				  } 		
		   
	        	 
		 /*         student3.setFname((String)listVal.get(0));
		            student3.setLname((String)listVal.get(1));
		            student3.setEtype((String)listVal.get(2));
		            student3.setPhoneno((String)listVal.get(3));
		            student3.setMailid((String)listVal.get(4));
		            student3.setEmpdoj((String)listVal.get(5));
		            student3.setEmpdesig((String)listVal.get(6));
		            student3.setDob((String)listVal2.get(0));
		            student3.setMailid2((String)listVal2.get(1));
		            student3.setMobileno((String)listVal2.get(2));
		            student3.setPhoneno2((String)listVal2.get(3));
		            student3.setFathername((String)listVal2.get(4));
		            student3.setEaddress1((String)listVal2.get(5));
		            student3.setEaddress2((String)listVal2.get(6));
		            student3.setEaddress3((String)listVal2.get(7));
		            student3.setPreviousem((String)listVal3.get(0));
		            student3.setFinyear((String)listVal3.get(1));
		            student3.setSdate((String)listVal3.get(2));
		            student3.setEdate((String)listVal3.get(3));
		            student3.setEsalary((String)listVal3.get(4));
		            student3.setTaxpaid((String)listVal3.get(5));
		            model.addAttribute("id", student3.getId());
				      model.addAttribute("fname", student3.getFname());
				      model.addAttribute("lname", student3.getLname());
				      model.addAttribute("etype", student3.getEtype());
				      model.addAttribute("phoneno", student3.getPhoneno());
				      model.addAttribute("mailid", student3.getMailid());
				      model.addAttribute("empdoj", student3.getEmpdoj());
				      model.addAttribute("empdesig", student3.getEmpdesig());
				      model.addAttribute("dob", student3.getDob());
				      model.addAttribute("mailid2", student3.getMailid2());
				      model.addAttribute("mobileno", student3.getMobileno());
				      model.addAttribute("phoneno2", student3.getPhoneno2());
				      model.addAttribute("fathername", student3.getFathername());
				      model.addAttribute("eaddress1", student3.getEaddress1());
				      model.addAttribute("eaddress2", student3.getEaddress2());
				      model.addAttribute("eaddress3", student3.getEaddress3());
				      model.addAttribute("employername", student3.getPreviousem());
				      model.addAttribute("finyear", student3.getFinyear());
				      model.addAttribute("sdate", student3.getSdate());
				      model.addAttribute("edate", student3.getEdate());
				      model.addAttribute("esalary", student3.getEsalary());
				      model.addAttribute("taxpaid", student3.getTaxpaid());
				 */
				      //Student student = new Student();
		             
				  
		   /*
				  else if(flag==false)
				  {
					  result3.addError(new FieldError("SpringWeb","value2","The requested id is not available"));
					  return "error";
				  }
			*/			  
				  //return "";
					 
				 //return new ModelAndView("result3", "command", new Student());			   
		      /*
		      model.addAttribute("fname", student.getFname());
		      model.addAttribute("lname", student.getLname());
		      model.addAttribute("etype", student.getEtype());
		      model.addAttribute("phoneno", student.getPhoneno());
		      model.addAttribute("mailid", student.getMailid());
		      model.addAttribute("empdoj", student.getEmpdoj());
		      model.addAttribute("empdesig", student.getEmpdesig());
		      model.addAttribute("dob", student.getDob());
		      model.addAttribute("mailid2", student.getMailid2());
		      model.addAttribute("mobileno", student.getMobileno());
		      model.addAttribute("phoneno2", student.getPhoneno2());
		      model.addAttribute("fathername", student.getFathername());
		      model.addAttribute("eaddress1", student.getEaddress1());
		      model.addAttribute("eaddress2", student.getEaddress2());
		      model.addAttribute("eaddress3", student.getEaddress3());
		      model.addAttribute("employername", student.getPreviousen());
		      model.addAttribute("finyear", student.getFinyear());
		      model.addAttribute("sdate", student.getSdate());
		      model.addAttribute("edate", student.getEdate());
		      model.addAttribute("esalary", student.getEsalary());
		      model.addAttribute("taxpaid", student.getTaxpaid());
		      */
           
		   
	     
		   /*
	           @RequestMapping(value = "/update2.html", method = RequestMethod.GET)
               public String index2(Map<String, Object> model) 
	           { 
               Student student = new Student();
               model.put("student2", student);
               return "update2";
               }
             */
		      return "";
		   }   

		   @RequestMapping(value = "/updateStudent2", method = RequestMethod.POST)
		   public String updateStudent2(@ModelAttribute("student3")StudentModel student3A, BindingResult result,
		   ModelMap model) {


			   
			   
			   validator.validate(student3A, result);
				  if (result.hasErrors()) {
						return "update2";
					}
				/*
			   
			   
			   String id=String.valueOf(student3A.getId());
			   boolean status=new DBOperation4().DBOP4(id,student3A.getFname(),student3A.getLname(),
					   student3A.getEtype(),student3A.getPhoneno(),student3A.getMailid(),student3A.getEmpdoj(),
					   student3A.getEmpdesig(),student3A.getDob(),student3A.getMailid2(),student3A.getMobileno(),
					   student3A.getPhoneno2(),student3A.getFathername(),student3A.getEaddress1(),student3A.getEaddress2(),
					   student3A.getEaddress3(),student3A.getPreviousem(),student3A.getFinyear(),
					   student3A.getSdate(),student3A.getEdate(),student3A.getEsalary(),student3A.getTaxpaid()); 
			  if (status==true){
		      model.addAttribute("id", student3A.getId());
		      model.addAttribute("fname", student3A.getFname());
		      model.addAttribute("lname", student3A.getLname());
		      model.addAttribute("etype", student3A.getEtype());
		      model.addAttribute("phoneno", student3A.getPhoneno());
		      model.addAttribute("mailid", student3A.getMailid());
		      model.addAttribute("empdoj", student3A.getEmpdoj());
		      model.addAttribute("empdesig", student3A.getEmpdesig());
		      model.addAttribute("dob", student3A.getDob());
		      model.addAttribute("mailid2", student3A.getMailid2());
		      model.addAttribute("mobileno", student3A.getMobileno());
		      model.addAttribute("phoneno2", student3A.getPhoneno2());
		      model.addAttribute("fathername", student3A.getFathername());
		      model.addAttribute("eaddress1", student3A.getEaddress1());
		      model.addAttribute("eaddress2", student3A.getEaddress2());
		      model.addAttribute("eaddress3", student3A.getEaddress3());
		      model.addAttribute("employername", student3A.getPreviousem());
		      model.addAttribute("finyear", student3A.getFinyear());
		      model.addAttribute("sdate", student3A.getSdate());
		      model.addAttribute("edate", student3A.getEdate());
		      model.addAttribute("esalary", student3A.getEsalary());
		      model.addAttribute("taxpaid", student3A.getTaxpaid());
			  }
			  else{}			  
		   */
		      			   
				  studentService.addStudent(student3A);
	     	  
				  if(student3A.getFname()!=null)
				  {
				  model.addAttribute("id", student3A.getId());
				  model.addAttribute("fname", student3A.getFname());
				  model.addAttribute("lname", student3A.getLname());
				  model.addAttribute("etype", student3A.getEtype());
				  model.addAttribute("phoneno", student3A.getPhoneno());
				  model.addAttribute("mailid", student3A.getMailid());
				  model.addAttribute("empdoj", student3A.getEmpdoj());
				  model.addAttribute("empdesig", student3A.getEmpdesig());
				  model.addAttribute("dob", student3A.getDob());
				  model.addAttribute("mailid2", student3A.getMailid2());
				  model.addAttribute("mobileno", student3A.getMobileno());
				  model.addAttribute("phoneno2", student3A.getPhoneno2());
				  model.addAttribute("fathername", student3A.getFathername());
				  model.addAttribute("eaddress1", student3A.getEaddress1());
				  model.addAttribute("eaddress2", student3A.getEaddress2());
				  model.addAttribute("eaddress3", student3A.getEaddress3());
				  model.addAttribute("employername", student3A.getPreviousem());
				  model.addAttribute("finyear", student3A.getFinyear());
				  model.addAttribute("sdate", student3A.getSdate());
				  model.addAttribute("edate", student3A.getEdate());
				  model.addAttribute("esalary", student3A.getEsalary());
				  model.addAttribute("taxpaid", student3A.getTaxpaid());
				     }
				    else{}
					
				  return "result3A";
	
		   
		   }
	

	      @RequestMapping(value = "/delete", method = RequestMethod.GET)
		   public ModelAndView student4() {
		      return new ModelAndView("delete", "command", new StudentModel());
		   }
		   
		   @RequestMapping(value = "/deleteStudent", method = RequestMethod.POST)
		   public String deleteStudent(@ModelAttribute("SpringWeb")StudentModel student4, BindingResult result4,
		   ModelMap model) {
			   /*
			   DBOperation5 ref=new DBOperation5(); 
			   boolean status=ref.DBOP5(student4); 
			   boolean flag;
			   flag=ref.getFlag();
			   System.out.println("D.FLAG:"+flag);
			   System.out.println("D.STATUS:"+status);
				*/  
		      /*
		      model.addAttribute("fname", student.getFname());
		      model.addAttribute("lname", student.getLname());
		      model.addAttribute("etype", student.getEtype());
		      model.addAttribute("phoneno", student.getPhoneno());
		      model.addAttribute("mailid", student.getMailid());
		      model.addAttribute("empdoj", student.getEmpdoj());
		      model.addAttribute("empdesig", student.getEmpdesig());
		      model.addAttribute("dob", student.getDob());
		      model.addAttribute("mailid2", student.getMailid2());
		      model.addAttribute("mobileno", student.getMobileno());
		      model.addAttribute("phoneno2", student.getPhoneno2());
		      model.addAttribute("fathername", student.getFathername());
		      model.addAttribute("eaddress1", student.getEaddress1());
		      model.addAttribute("eaddress2", student.getEaddress2());
		      model.addAttribute("eaddress3", student.getEaddress3());
		      model.addAttribute("employername", student.getPreviousen());
		      model.addAttribute("finyear", student.getFinyear());
		      model.addAttribute("sdate", student.getSdate());
		      model.addAttribute("edate", student.getEdate());
		      model.addAttribute("esalary", student.getEsalary());
		      model.addAttribute("taxpaid", student.getTaxpaid());
		      */
			   boolean result=studentService.deleteStudent(student4);
			
			   if(result==true)
			   {
				   
				   model.addAttribute("id", student4.getId());
				   return "result4";
			   }
			  else if(result==false)
			  {
				  result4.addError(new FieldError("SpringWeb","value3","The requested id is not available"));
   			      return "error";
			  }
		     
			   return "";
		   }	
}
		   
		   
		  