package com.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


//@Table(name="student_info2")
@Entity(name="student_info2")
public class StudentModel implements Serializable
{
	
	private static final long serialVersionUID = -7235830585868343479L;
	
	   @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
	   @Column(name = "id")
	   private Integer id;
	   @Column(name = "fname")
	   private String fname;
	   @Column(name = "lname")
	   private String lname;
	   @Column(name = "etype")
	   private String etype;
	   @Column(name = "phoneno")
	   private String phoneno;
	   @Column(name = "mailid")
	   private String mailid;
	   @Column(name = "empdoj")
	   private String empdoj;
	   @Column(name = "empdesig")
	   private String empdesig;
	   @Column(name = "dob")
	   private String dob;
	   @Column(name = "mailid2")
	   private String mailid2;
	   @Column(name = "mobileno")
	   private String mobileno;
	   @Column(name = "phoneno2")
	   private String phoneno2;
	   @Column(name = "fathername")
	   private String fathername;
	   @Column(name = "eaddress1")
	   private String eaddress1;
	   @Column(name = "eaddress2")
	   private String eaddress2;
	   @Column(name = "eaddress3")
	   private String eaddress3;
	   @Column(name = "previousem")
	   private String previousem;
	   @Column(name = "finyear")
	   private String finyear;
	   @Column(name = "sdate")
	   private String sdate;
	   @Column(name = "edate")
	   private String edate;
	   @Column(name = "esalary")
	   private String esalary;
	   @Column(name = "taxpaid")
	   private String taxpaid;
	   @Column(name = "value")
	   private String value;
	   public void setId(Integer id) {
	      this.id = id;
	   }
	   public Integer getId() {
	      return id;
	   }

	   public void setFname(String fname) {
	      this.fname = fname;
	   }
	   public String getFname() {
	      return fname;
	   }

	   public void setLname(String lname) {
		      this.lname = lname;
		   }
		   public String getLname() {
		      return lname;
		   }
		   public void setEtype(String etype) {
			      this.etype = etype;
			   }
			   public String getEtype() {
			      return etype;
			   }
			   public void setPhoneno(String phoneno) {
				      this.phoneno = phoneno;
				   }
				   public String getPhoneno() {
				      return phoneno;
				   }
				   public void setMailid(String mailid) {
					      this.mailid = mailid;
					   }
					   public String getMailid() {
					      return mailid;
					   }
					   public void setEmpdoj(String empdoj) {
						      this.empdoj = empdoj;
					   }
					  public String getEmpdoj() {
						      return empdoj;
					   }
					   public void setEmpdesig(String empdesig) {
						      this.empdesig = empdesig;
					   }
					  public String getEmpdesig() {
						      return empdesig;
					   }
					   public void setDob(String dob) {
						      this.dob = dob;
					   }
					  public String getDob() {
						      return dob;
					   }
					  public void setMailid2(String mailid2) {
					      this.mailid2 = mailid2;
				   }
				  public String getMailid2() {
					      return mailid2;
				   }
				  public void setMobileno(String mobileno) {
				      this.mobileno = mobileno;
			   }
			  public String getMobileno() {
				      return mobileno;
			   }
			  public void setPhoneno2(String phoneno2) {
			      this.phoneno2 = phoneno2;
		   }
		  public String getPhoneno2() {
			      return phoneno2;
		   }
		  
					  
					   public void setFathername(String fathername) {
						      this.fathername = fathername;
					   }
					  public String getFathername() {
						      return fathername;
					   }
					   public void setEaddress1(String eaddress1) {
						      this.eaddress1 = eaddress1;
					   }
					  public String getEaddress1() {
						      return eaddress1;
					   }
					  public void setEaddress2(String eaddress2) {
					      this.eaddress2 = eaddress2;
				   }
				   public String getEaddress2() 
				   {
					      return eaddress2;
				   }
				  public void setEaddress3(String eaddress3) 
				   {
					      this.eaddress3 = eaddress3;
				   }
				  public String getEaddress3() {
					      return eaddress3;
				   }
					   public void setPreviousem(String previousem) {
						      this.previousem =previousem;
					   }
					  public String getPreviousem() {
						      return previousem;
					   }
					public void setFinyear(String finyear) {
						      this.finyear = finyear;
					   }
					  public String getFinyear() {
						      return finyear ;
					   }
					   public void setSdate(String sdate) {
						      this.sdate = sdate;
					   }
					  public String getSdate() {
						      return sdate;
					   }
					   public void setEdate(String edate) {
						      this.edate = edate;
					   }
					  public String getEdate() {
						      return edate;
					   }
					   public void setEsalary(String esalary) {
						      this.esalary = esalary;
					   }
					  public String getEsalary() {
						      return esalary;
					   }
					   public void setTaxpaid(String taxpaid) {
						      this.taxpaid = taxpaid;
					   }
					  public String getTaxpaid() {
						      return taxpaid;
					   }
					public String getValue() {
						return value;
					}
					public void setValue(String value) {
						this.value = value;
					}		  
}

