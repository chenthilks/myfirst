package com.service;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBOperation4
{
  boolean status=false;
  
  public  boolean DBOP4(String employeeId,String employeeFname,String employeeLname,String employeeType,String phoneNo,String emailId,String employeeDoj,String employeeDesignation,String employeeDob,String emailId2,String mobileNo,String phoneNo2,String fatherName,String employeeAddress1,String employeeAddress2,String employeeAddress3,String prevEmpName,String finYear,String startDate,String endDate,String employeeSalary,String taxPaid)
  {
		String CREATED_BY_USER="USER";
	    Long CREATED_BY_DATE2=(long) new Date(0).getDate();
	    Date CREATED_BY_DATE=new Date(CREATED_BY_DATE2);
	    //String MODIFIED_BY_USER=request.getParameter("MODIFIED_BY_USER");
	    String MODIFIED_BY_USER=CREATED_BY_USER;
	    //Long MODIFIED_BY_DATE2=Long.parseLong(request.getParameter("MODIFIED_BY_DATE"));
	    Date MODIFIED_BY_DATE=CREATED_BY_DATE;
	    Connection con=null;
	    try{  
	    	Class.forName("com.mysql.jdbc.Driver");  
	    	
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    	con.setAutoCommit(false);
	     	Statement stmt=con.createStatement();  
	     	
	
	    	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");

	    	int i=stmt.executeUpdate("UPDATE sys.EMPLOYEE_PRIMARY_INFO SET EMPLOYEE_FNAME='"+employeeFname+"',EMPLOYEE_LNAME='"+employeeLname+"',EMPLOYEE_TYPE='"+employeeType+"',PHONE_NO='"+phoneNo+"',EMAIL_ID='"+emailId+"',EMPLOYEE_DOJ='"+employeeDoj+"',EMPLOYEE_DESIGNATION='"+employeeDesignation+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID='"+employeeId+"'");
	        int j=stmt.executeUpdate("UPDATE sys.EMPLOYEE_PERSONAL_INFO SET EMPLOYEE_DOB='"+employeeDob+"',SECONDARY_EMAIL_ID='"+emailId2+"',MOBILE_NO='"+mobileNo+"',PHONE_NO2='"+phoneNo2+"',FATHER_NAME='"+fatherName+"',EMPLOYEE_ADDRESS1='"+employeeAddress1+"',EMPLOYEE_ADDRESS2='"+employeeAddress2+"',EMPLOYEE_ADDRESS3='"+employeeAddress3+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID='"+employeeId+"'"); 
	        int k=stmt.executeUpdate("UPDATE sys.EMPLOYER_INFO SET PREVIOUS_EMPLOYER_NAME='"+prevEmpName+"',FIN_YEAR='"+finYear+"',START_DATE='"+startDate+"',END_DATE='"+endDate+"',EMPLOYEE_SALARY='"+employeeSalary+"',TOTAL_TAX_PAID='"+taxPaid+"',CREATED_BY_USER='"+CREATED_BY_USER+"',CREATED_BY_DATE='"+CREATED_BY_DATE+"',MODIFIED_BY_USER='"+MODIFIED_BY_USER+"',MODIFIED_BY_DATE='"+MODIFIED_BY_DATE+"' WHERE EMPLOYEE_ID= '"+employeeId+"'");
	    	
	        /* 		
	        ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	    	
	    	while(rs.next()) 
	    	{	
	    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	    	}
	    	*/	    
	        status=true;
	    	System.out.println(i+":"+j+":"+k);
	    	
	    	//out.println("<br/>");
	    	//out.println("Employee table updated...");
	    	   
	    	  con.commit();
	    	  con.close();  
	    	}
	    	catch(Exception e)
	    	{ 
	    	 System.out.println(e);
	    	 try{
		          con.rollback();
		          }
		          catch(Exception e1){}
	    	 //out.println("<br/>");
	    	 //out.println("The exception occured is..."+e);
	    	 // request.setAttribute("exception_message",e.getMessage());
	    	 // RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
	         //rd.forward(request,response);      
	    	}   		
	return status;
	}
}
