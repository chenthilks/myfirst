package com.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;

import com.spring.bean.Student;

public class DBOperation2 
{
  boolean status=false;
  int employeeId;
  String employeeFname;
  String employeeLname;
  String employeeType;
  String phoneNo;
  String emailId;
  String employeeDoj;
  String employeeDesignation;
  String employeeDob;
  String emailId2;
  String mobileNo;
  String phoneNo2;
  String fatherName;
  String employeeAddress1;
  String employeeAddress2;
  String employeeAddress3;
  String prevEmpName;
  String finYear;
  String startDate;
  String endDate;
  String employeeSalary;
  String taxPaid;
  public  boolean DBOP2(Student student)
		  
  {
	    employeeId=student.getId();
	    employeeFname=student.getFname();
	    employeeLname=student.getLname();
	    employeeType=student.getEtype();
	    phoneNo=student.getPhoneno();
	    emailId=student.getMailid();
	    employeeDoj=student.getEmpdoj();
	    employeeDesignation=student.getEmpdesig();
	    employeeDob=student.getDob();
	    emailId2=student.getMailid2();
	    mobileNo=student.getMobileno();
	    phoneNo2=student.getPhoneno2();
	    fatherName=student.getFathername();
	    employeeAddress1=student.getEaddress1();
	    employeeAddress2=student.getEaddress2();
	    employeeAddress3=student.getEaddress3();
	    prevEmpName=student.getPreviousem();
	    finYear=student.getFinyear();
	    startDate=student.getSdate();
	    endDate=student.getEdate();
	    employeeSalary=student.getEsalary();
	    taxPaid=student.getTaxpaid();
	    
	    
		String CREATED_BY_USER="USER";
	    Long CREATED_BY_DATE2=(long) new Date(0).getDate();
	    Date CREATED_BY_DATE=new Date(CREATED_BY_DATE2);
	    //String MODIFIED_BY_USER=request.getParameter("MODIFIED_BY_USER");
	    String MODIFIED_BY_USER=CREATED_BY_USER;
	    //Long MODIFIED_BY_DATE2=Long.parseLong(request.getParameter("MODIFIED_BY_DATE"));
	    Date MODIFIED_BY_DATE=CREATED_BY_DATE;
	    Connection con=null;
	    try{  
	    	Class.forName("com.mysql.jdbc.Driver");  
	        
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","chenthil");  
	    	con.setAutoCommit(false);
	     	Statement stmt=con.createStatement();  
	
	    	//int i=stmt.executeUpdate("insert into (fname,type) values('"+val1+"','"+val2+"')");

	    	int i=stmt.executeUpdate("insert into sys.EMPLOYEE_PRIMARY_INFO(EMPLOYEE_ID,EMPLOYEE_FNAME,EMPLOYEE_LNAME,EMPLOYEE_TYPE,PHONE_NO,EMAIL_ID,EMPLOYEE_DOJ,EMPLOYEE_DESIGNATION,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employeeId+"','"+employeeFname+"','"+employeeLname+"','"+employeeType+"','"+phoneNo+"','"+emailId+"','"+employeeDoj+"','"+employeeDesignation+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	        int j=stmt.executeUpdate("insert into sys.EMPLOYEE_PERSONAL_INFO(EMPLOYEE_ID,EMPLOYEE_DOB,SECONDARY_EMAIL_ID,MOBILE_NO,PHONE_NO2,FATHER_NAME,EMPLOYEE_ADDRESS1,EMPLOYEE_ADDRESS2,EMPLOYEE_ADDRESS3,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE) VALUES ('"+employeeId+"','"+employeeDob+"','"+emailId2+"','"+mobileNo+"','"+phoneNo2+"','"+fatherName+"','"+employeeAddress1+"','"+employeeAddress2+"','"+employeeAddress3+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"' )"); 
	        int k=stmt.executeUpdate("insert into sys.EMPLOYER_INFO(EMPLOYEE_ID,PREVIOUS_EMPLOYER_NAME,FIN_YEAR,START_DATE,END_DATE,EMPLOYEE_SALARY,TOTAL_TAX_PAID,CREATED_BY_USER,CREATED_BY_DATE,MODIFIED_BY_USER,MODIFIED_BY_DATE)VALUES ('"+employeeId+"','"+prevEmpName+"','"+finYear+"','"+startDate+"','"+endDate+"','"+employeeSalary+"','"+taxPaid+"','"+CREATED_BY_USER+"','"+CREATED_BY_DATE+"','"+MODIFIED_BY_USER+"','"+MODIFIED_BY_DATE+"')");
	    	
	        /* 		
	        ResultSet rs=stmt.executeQuery("select * from test_employee");  	    	
	    	
	    	while(rs.next()) 
	    	{	
	    	System.out.println(rs.getString(1)+" : "+rs.getString(2));  
	    	}
	    	*/	    
	        status=true;
	    	System.out.println(i+":"+j+":"+k);
	    	
	    	//out.println("<br/>");
	    	//out.println("Employee table updated...");
	    	  
	    	  con.commit();
	    	  con.close();  
	    	}
	    	catch(Exception e)
	    	{ 
	          System.out.println(e);
	          try{
	          con.rollback();
	          }
	          catch(Exception e1){}
	           //out.println("<br/>");
	    	 //out.println("The exception occured is..."+e);
	    	 // request.setAttribute("exception_message",e.getMessage());
	    	 // RequestDispatcher rd=request.getRequestDispatcher("view/login-form.jsp");
	         //rd.forward(request,response);      
	    	}   		
	    return status;
	}
}